//Document prepared by Dylan Sheffer (Dillpickle) for iDTech Camps 2015

package com.example.examplemod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.RenderItem;
import net.minecraft.client.resources.model.ModelResourceLocation;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.Item.ToolMaterial;
import net.minecraftforge.common.util.EnumHelper;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.relauncher.Side;

import com.camp.TechTab;
import com.camp.block.BlockManager;
import com.camp.item.ItemManager;

@Mod(modid = ExampleMod.MODID, version = ExampleMod.VERSION)
public class ExampleMod {
	// The ID of the Mod. REMEMBER THIS!!!
	public static final String MODID = "examplemod";
	public static final String VERSION = "1.0";

	// Declare any Custom Materials you may need
	public static ToolMaterial CustomToolMaterial;

	// Setting iDTech Mod Creative Tab
	public static final TechTab techTab = new TechTab("iDTech");

	@EventHandler
	public void preinit(FMLPreInitializationEvent event) {
		// Initialize the custom material
		CustomToolMaterial = EnumHelper.addToolMaterial("Custom", 3, 100, 4,
				50, 0);

		// Initializes and Registers any Custom Items
		ItemManager.mainRegistry();
		BlockManager.mainRegistry();

	}

	@EventHandler
	public void init(FMLInitializationEvent event) {
		if (event.getSide() == Side.CLIENT) {
			// Creates the renderItem Object
			RenderItem renderItem = Minecraft.getMinecraft().getRenderItem();

			// Registers the rendering files for the custom items. Change the
			// parameters where its necessary.
			renderItem.getItemModelMesher().register(
					ItemManager.customItem,
					0,
					new ModelResourceLocation(this.MODID + ":"
							+ ItemManager.customItem.name, "inventory"));
			renderItem.getItemModelMesher().register(
					ItemManager.customPickaxe,
					0,
					new ModelResourceLocation(this.MODID + ":"
							+ ItemManager.customPickaxe.name, "inventory"));
			renderItem.getItemModelMesher().register(
					ItemManager.customFood,
					0,
					new ModelResourceLocation(this.MODID + ":"
							+ ItemManager.customFood.name, "inventory"));
			renderItem.getItemModelMesher().register(
					Item.getItemFromBlock(BlockManager.customBlock),
					0,
					new ModelResourceLocation(this.MODID + ":"
							+ BlockManager.customBlock.name, "inventory"));
			renderItem.getItemModelMesher().register(
					ItemManager.customProjectile,
					0,
					new ModelResourceLocation(this.MODID + ":"
							+ ItemManager.customProjectile.name, "inventory"));
		}

	}
}
