//Document prepared by Dylan Sheffer (Dillpickle) for iDTech Camps 2015
package com.camp.item;

import com.camp.entity.projectile.EntityCustomProjectile;
import com.example.examplemod.ExampleMod;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.projectile.EntitySnowball;
import net.minecraft.item.Item;
import net.minecraft.item.ItemSnowball;
import net.minecraft.item.ItemStack;
import net.minecraft.stats.StatList;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class CustomProjectile extends ItemSnowball {
	public final String name = "CustomProjectile";

	public CustomProjectile() {
		this.setUnlocalizedName(ExampleMod.MODID + "_" + name);
		//Places the item inside the custom tab
		this.setCreativeTab(ExampleMod.techTab);
	}

	/**
	 * Called when a Block is right-clicked with this Item
	 * 
	 * @param pos
	 *            The block being right-clicked
	 * @param side
	 *            The side being right-clicked
	 */
	@Override
	public boolean onItemUse(ItemStack stack, EntityPlayer playerIn,
			World worldIn, BlockPos pos, EnumFacing side, float hitX,
			float hitY, float hitZ) {
		return false;
	}

	/**
	 * Called whenever this item is equipped and the right mouse button is
	 * pressed. Args: itemStack, world, entityPlayer
	 */
	@Override
	public ItemStack onItemRightClick(ItemStack itemStackIn, World worldIn,
			EntityPlayer playerIn) {
		if (!playerIn.capabilities.isCreativeMode) {
			--itemStackIn.stackSize;
		}

		worldIn.playSoundAtEntity(playerIn, "random.bow", 0.5F,
				0.4F / (itemRand.nextFloat() * 0.4F + 0.8F));

		if (!worldIn.isRemote) {
			worldIn.spawnEntityInWorld(new EntityCustomProjectile(worldIn,
					playerIn));
		}

		return itemStackIn;
	}

	/**
	 * Makes the SpleefBall Shimmer
	 * @return Boolean Makes it have the enchantment effect
	 */
	@Override
	@SideOnly(Side.CLIENT)
	public boolean hasEffect(ItemStack stack) {
		return false;
	}

}
