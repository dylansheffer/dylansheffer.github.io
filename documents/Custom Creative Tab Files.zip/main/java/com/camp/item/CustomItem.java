package com.camp.item;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;

import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.world.World;

import com.example.examplemod.ExampleMod;

//Make sure that the custom item extends Item
public class CustomItem extends Item {

	// 1. Give the Item a name
	public static final String name = "CustomItem";

	public CustomItem() {
		super();

		// Sets the Unlocalized Name. This name can be used to summon the item
		// using commands
		this.setUnlocalizedName(ExampleMod.MODID + "_" + this.name);

		// Places the item in the Creative Menu
		this.setCreativeTab(ExampleMod.techTab);

		// Sets the Max amount this item can be stacked
		this.setMaxStackSize(1);

	}

	@Override
	public boolean onItemUse(ItemStack stack, EntityPlayer playerIn,
			World worldIn, BlockPos pos, EnumFacing side, float hitX,
			float hitY, float hitZ) {

		/**
		 * Creates the Explosion
		 * 
		 * @param The
		 *            entity that summoned the explosion
		 * @param X
		 *            ,Y,Z coordinance where the explosion happens
		 * @param Explosion
		 *            Strength
		 */
		worldIn.createExplosion(playerIn, pos.getX() + hitX, pos.getY() + hitY,
				pos.getZ() + hitZ, 1.0f, true);

		// Returns when the item is used
		return super.onItemUse(stack, playerIn, worldIn, pos, side, hitX, hitY,
				hitZ);
	}

}