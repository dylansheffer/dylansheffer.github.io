//Document prepared by Dylan Sheffer (Dillpickle) for iDTech Camps 2015
package com.camp.item;

import com.example.examplemod.ExampleMod;

import net.minecraft.item.Item.ToolMaterial;
import net.minecraft.tileentity.TileEntity;
import net.minecraftforge.fml.common.registry.GameRegistry;

public class ItemManager {

	// 1. Declare Items Here
	public static CustomItem customItem;
	public static CustomPickaxe customPickaxe;
	public static CustomFood customFood;
	public static CustomProjectile customProjectile;

	public static void mainRegistry() {
		initializeItem();
		registerItem();
	}

	// 2. Initialize the items here. Pass in any necessary parameters when
	// initializing
	public static void initializeItem() {
		customItem = new CustomItem();
		customPickaxe = new CustomPickaxe(ExampleMod.CustomToolMaterial);
		customFood = new CustomFood(10, 0.5f, false);
		customProjectile = new CustomProjectile();
	}

	// 3. Register the Item

	/**
	 * Registers the item in the game
	 * 
	 * @param Item
	 *            Object
	 * @param Name
	 *            of Item
	 */
	public static void registerItem() {
		GameRegistry.registerItem(customItem, customItem.name);
		GameRegistry.registerItem(customPickaxe, customPickaxe.name);
		GameRegistry.registerItem(customFood, customFood.name);
		GameRegistry.registerItem(customProjectile, customProjectile.name);

	}

}
