//Document prepared by Dylan Sheffer (Dillpickle) for iDTech Camps 2015
package com.camp.block;

import com.example.examplemod.ExampleMod;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.boss.EntityDragon;
import net.minecraft.entity.monster.EntitySilverfish;
import net.minecraft.entity.monster.EntitySlime;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.util.BlockPos;
import net.minecraft.world.World;

public class CustomBlock extends Block {

	public static final String name = "CustomBlock";

	public CustomBlock() {
		super(Material.rock);
		this.setUnlocalizedName(ExampleMod.MODID + "_" + name);
		this.setCreativeTab(ExampleMod.techTab);
		this.setLightLevel(0.8f);
		this.setHardness(10.0f);
		this.setResistance(10.0f);
		this.setHarvestLevel("pickaxe", 1);
	}

	@Override
	public void onEntityCollidedWithBlock(World worldIn, BlockPos pos,
			Entity entityIn) {
		super.onEntityCollidedWithBlock(worldIn, pos, entityIn);
		if (entityIn instanceof EntityLivingBase) {
			((EntityLivingBase) entityIn).setFire(10);
		}
	}

	/**
	 * Spawns this Block's drops into the World as EntityItems.
	 * 
	 * @param chance
	 *            The chance that each Item is actually spawned (1.0 = always,
	 *            0.0 = never)
	 * @param fortune
	 *            The player's fortune level
	 */
	public void dropBlockAsItemWithChance(World worldIn, BlockPos pos,
			IBlockState state, float chance, int fortune) {
		if (!worldIn.isRemote
				&& worldIn.getGameRules()
						.getGameRuleBooleanValue("doTileDrops")) {
			// Creates a slime on block break
			EntitySlime entityslime = new EntitySlime(worldIn);
			entityslime
					.setLocationAndAngles((double) pos.getX() + 0.5D,
							(double) pos.getY(), (double) pos.getZ() + 0.5D,
							0.0F, 0.0F);
			worldIn.spawnEntityInWorld(entityslime);
			entityslime.spawnExplosionParticle();
		}
	}
}
