//Document prepared by Dylan Sheffer (Dillpickle) for iDTech Camps 2015

package com.camp.entity.projectile;

import net.minecraft.block.BlockSnow;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.EntityBlaze;
import net.minecraft.entity.projectile.EntitySnowball;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.world.World;

public class EntityCustomProjectile extends EntitySnowball {
	// The different constructors used by the snowball class
	public EntityCustomProjectile(World worldIn) {
		super(worldIn);
	}

	public EntityCustomProjectile(World worldIn, EntityLivingBase p_i1774_2_) {
		super(worldIn, p_i1774_2_);
	}

	public EntityCustomProjectile(World worldIn, double x, double y, double z) {
		super(worldIn, x, y, z);
	}

	/**
	 * Called when this EntityThrowable hits a block or entity.
	 */
	@Override
	protected void onImpact(MovingObjectPosition p_70184_1_) {
		// Causes damage when it hits an entity
		if (p_70184_1_.entityHit != null) {
			byte b0 = 0;

			p_70184_1_.entityHit.attackEntityFrom(
					DamageSource.causeThrownDamage(this, this.getThrower()),
					(float) b0);
		}

		// Spawns Firework Particles (only visible in large numbers)
		for (int i = 0; i < 8; ++i) {
			this.worldObj.spawnParticle(EnumParticleTypes.FIREWORKS_SPARK,
					this.posX, this.posY, this.posZ, 0.0D, 0.0D, 0.0D,
					new int[0]);
		}

		// Creates the explosion where the entity lands. The integer parameter
		// controls the strength and size of explosion
		this.worldObj.createExplosion(this, this.posX, this.posY, this.posZ, 1,
				true);

		// Destroys the Entity after it lands, so it doesn't bury through the
		// whole ground
		if (!this.worldObj.isRemote) {
			this.setDead();
		}
	}
}
