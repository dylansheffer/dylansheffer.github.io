//Document prepared by Dylan Sheffer (Dillpickle) for iDTech Camps 2015

package com.camp;

import com.camp.item.ItemManager;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;

public class TechTab extends CreativeTabs {

	/**
	 * Constructor that creates the custom tab
	 * 
	 * @param label
	 *            The name of the tab (Will be changed in the Lang File later)
	 */
	public TechTab(String label) {
		super(label);
		this.setBackgroundImageName("iDTech.png");
	}

	/**
	 * Creates an icon for the Custom Tab
	 * 
	 * @return Item The item that will be used to generate an icon for the tab
	 */
	@Override
	public Item getTabIconItem() {
		return ItemManager.customItem;
	}

}